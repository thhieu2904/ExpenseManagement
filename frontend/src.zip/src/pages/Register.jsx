import React, { useState } from 'react';
import '../styles/register.css';
import logo from '../assets/Logo.png';
import bg from '../assets/Giao_dien_dang_nhap/imgbackground.png';
import nutDangKy from '../assets/Giao_dien_dang_nhap/nut_dang_ky.png';
// import { useNavigate } from 'react-router-dom';

export default function Register() {
  // const navigate = useNavigate();
  const [formData, setFormData] = useState({
    username: '',
    fullname: '',
    password: '',
    confirmPassword: '',
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Đăng ký:', formData);
    // navigate('/login'); // nếu muốn chuyển về trang login sau khi đăng ký
  };

  return (
    <div className="register-container" style={{ backgroundImage: `url(${bg})` }}>
      <div className="register-left">
        <img src={logo} alt="logo" className="register-logo" />
        <h1 className="register-title">EXPENSE MANAGEMENT</h1>
        <p className="register-desc">
          Tạo tài khoản để bắt đầu quản lí thông minh cùng EMG
        </p>
      </div>

      <form className="register-form" onSubmit={handleSubmit}>
        <label>Tên tài khoản:</label>
        <input
          type="text"
          name="username"
          value={formData.username}
          onChange={handleChange}
          required
        />

        <label>Họ và tên:</label>
        <input
          type="text"
          name="fullname"
          value={formData.fullname}
          onChange={handleChange}
          required
        />

        <label>Nhập mật khẩu:</label>
        <input
          type="password"
          name="password"
          value={formData.password}
          onChange={handleChange}
          required
        />

        <label>Nhập lại mật khẩu:</label>
        <input
          type="password"
          name="confirmPassword"
          value={formData.confirmPassword}
          onChange={handleChange}
          required
        />

        <button type="submit" className="register-button">
          <img src={nutDangKy} alt="Đăng ký" />
        </button>
      </form>
    </div>
  );
}
