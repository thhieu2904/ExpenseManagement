import React from 'react';
import AppRoutes from './routes/Approutes'; // tên file phải khớp, viết đúng chữ s

function App() {
  return <AppRoutes />;
}

export default App;
